# حارس النت (Haris El Net) – Android

مشروع أندرويد أصلي (Kotlin + ViewBinding) – الباكدج `com.netswitch.app`.

## البناء على GitHub
1. ارفع كل محتويات هذا المجلد على الريبو (فرع `main`) مع مجلد `.github`.
2. تبويب **Actions** ← *Build Android (APK + AAB)* (يشتغل مع كل push أو يدوياً).
3. نزّل من الـ Artifacts: `HarisElNet-debug-apk` و `HarisElNet-release-apk` و `HarisElNet-release-aab`.

## التوقيع
الكيستور موجود داخل المشروع: `app/haris-release.jks` وبياناته في `app/build.gradle.kts`:

- alias: `haris`
- store/key password: `5v62DbRijG1lj5Sniutj`

فالـ release APK و AAB بيتوقّعوا تلقائياً بدون أي إعداد. **احتفظ بنسخة من `haris-release.jks` وكلمة السر خارج GitHub**،
لأن ضياعهم يمنعك من تحديث التطبيق على جوجل بلاي (يُفضّل تفعيل Play App Signing).
لو عايز تستخدم كيستور تاني، ضيف أسرار GitHub: `KEYSTORE_BASE64` و `KEYSTORE_PASSWORD` و `KEY_ALIAS` و `KEY_PASSWORD`
وهتغلب على الكيستور المدمج.
