plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val envKeystorePath: String? = System.getenv("KEYSTORE_PATH")
val useEnvKeystore = envKeystorePath != null && file(envKeystorePath).exists()

android {
    namespace = "com.netswitch.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.netswitch.app"
        minSdk = 26
        targetSdk = 34
        versionCode = (System.getenv("VERSION_CODE") ?: "1").toInt()
        versionName = "1.0.0"
    }

    signingConfigs {
        create("release") {
            if (useEnvKeystore) {
                // Optional override from GitHub secrets
                storeFile = file(envKeystorePath!!)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            } else {
                // Keystore bundled inside the project (app/haris-release.jks)
                storeFile = file("haris-release.jks")
                storePassword = "5v62DbRijG1lj5Sniutj"
                keyAlias = "haris"
                keyPassword = "5v62DbRijG1lj5Sniutj"
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("release")
        }
    }

    buildFeatures {
        viewBinding = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
