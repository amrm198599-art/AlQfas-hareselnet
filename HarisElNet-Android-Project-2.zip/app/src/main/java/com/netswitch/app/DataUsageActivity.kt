package com.netswitch.app

import android.content.Intent
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.google.android.material.tabs.TabLayout
import com.netswitch.app.databinding.ActivityDataUsageBinding
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.concurrent.TimeUnit

class DataUsageActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDataUsageBinding
    private lateinit var helper: NetworkStatsHelper
    private lateinit var prefs: Prefs
    private lateinit var usageAdapter: AppUsageAdapter
    private var currentTabIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDataUsageBinding.inflate(layoutInflater)
        setContentView(binding.root)
        helper = NetworkStatsHelper(this)
        prefs = Prefs.getInstance(this)

        setupToolbar()
        setupRecyclerView()
        setupTabs()
        setupPermissionButton()
        setupDailyLimitSection()
    }

    override fun onResume() {
        super.onResume()
        checkPermissionAndLoadData()
    }

    private fun setupToolbar() {
        binding.toolbarUsage.setNavigationOnClickListener { finish() }
    }

    private fun setupRecyclerView() {
        usageAdapter = AppUsageAdapter(packageManager)
        binding.rvAppUsage.layoutManager = LinearLayoutManager(this)
        binding.rvAppUsage.adapter = usageAdapter
    }

    private fun setupTabs() {
        binding.tabLayoutPeriod.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                currentTabIndex = tab.position
                if (helper.hasUsageStatsPermission()) loadAppUsageForTab(currentTabIndex)
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun setupPermissionButton() {
        binding.btnGrantUsagePermission.setOnClickListener {
            try {
                startActivity(
                    Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).setData(Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                try {
                    startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                } catch (e2: Exception) {
                    Toast.makeText(this, "تعذر فتح صفحة الإعدادات مباشرة", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun setupDailyLimitSection() {
        val current = prefs.getDailyMobileLimitMb()
        if (current > 0) binding.etDailyLimit.setText(current.toString())
        binding.btnSaveLimit.setOnClickListener {
            val value = binding.etDailyLimit.text?.toString()?.trim()?.toIntOrNull() ?: 0
            prefs.setDailyMobileLimitMb(value)
            prefs.setLastAlert80Day(0L)
            prefs.setLastAlert100Day(0L)
            if (value > 0) scheduleDailyLimitWorker() else cancelDailyLimitWorker()
            Toast.makeText(this, R.string.usage_limit_saved_toast, Toast.LENGTH_SHORT).show()
        }
    }

    private fun scheduleDailyLimitWorker() {
        val request = PeriodicWorkRequestBuilder<DailyLimitWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(applicationContext).enqueueUniquePeriodicWork(
            DailyLimitWorker.UNIQUE_WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, request
        )
    }

    private fun cancelDailyLimitWorker() {
        WorkManager.getInstance(applicationContext).cancelUniqueWork(DailyLimitWorker.UNIQUE_WORK_NAME)
    }

    private fun checkPermissionAndLoadData() {
        if (!helper.hasUsageStatsPermission()) {
            binding.layoutPermissionRequired.visibility = View.VISIBLE
            binding.scrollUsageContent.visibility = View.GONE
            return
        }
        binding.layoutPermissionRequired.visibility = View.GONE
        binding.scrollUsageContent.visibility = View.VISIBLE
        loadTodayOverviewAndChart()
        loadAppUsageForTab(currentTabIndex)
    }

    private fun startOfDay(offsetDays: Int = 0): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        c.add(Calendar.DAY_OF_YEAR, offsetDays)
        return c.timeInMillis
    }

    private fun getTimeRangeForTab(tab: Int): Pair<Long, Long> {
        val now = System.currentTimeMillis()
        return when (tab) {
            0 -> startOfDay() to now
            1 -> startOfDay(-1) to startOfDay()
            2 -> startOfDay(-6) to now
            else -> {
                val c = Calendar.getInstance()
                c.set(Calendar.DAY_OF_MONTH, 1)
                c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0)
                c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
                c.timeInMillis to now
            }
        }
    }

    private fun loadTodayOverviewAndChart() {
        lifecycleScope.launch {
            try {
                val start = startOfDay()
                val now = System.currentTimeMillis()
                val mobile = helper.querySummaryForNetwork(ConnectivityManager.TYPE_MOBILE, start, now)
                val wifi = helper.querySummaryForNetwork(ConnectivityManager.TYPE_WIFI, start, now)
                binding.tvTotalUsageToday.text = DataFormatter.formatBytes(this@DataUsageActivity, mobile.totalBytes + wifi.totalBytes)
                binding.tvMobileTotal.text = DataFormatter.formatBytes(this@DataUsageActivity, mobile.totalBytes)
                binding.tvMobileRxTx.text = "تحميل: " + DataFormatter.formatBytes(this@DataUsageActivity, mobile.rxBytes) +
                    " | رفع: " + DataFormatter.formatBytes(this@DataUsageActivity, mobile.txBytes)
                binding.tvWifiTotal.text = DataFormatter.formatBytes(this@DataUsageActivity, wifi.totalBytes)
                binding.tvWifiRxTx.text = "تحميل: " + DataFormatter.formatBytes(this@DataUsageActivity, wifi.rxBytes) +
                    " | رفع: " + DataFormatter.formatBytes(this@DataUsageActivity, wifi.txBytes)
                binding.chartLast7Days.setData(helper.queryLast7DaysUsage())
            } catch (e: Exception) {
                Toast.makeText(this@DataUsageActivity, R.string.usage_query_error, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun loadAppUsageForTab(tabIndex: Int) {
        binding.pbLoadingApps.visibility = View.VISIBLE
        binding.tvNoUsageData.visibility = View.GONE
        lifecycleScope.launch {
            try {
                val (start, end) = getTimeRangeForTab(tabIndex)
                val list = helper.queryAppsUsage(start, end)
                usageAdapter.submitList(list)
                binding.tvNoUsageData.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            } catch (e: Exception) {
                Toast.makeText(this@DataUsageActivity, R.string.usage_query_error, Toast.LENGTH_LONG).show()
            } finally {
                binding.pbLoadingApps.visibility = View.GONE
            }
        }
    }
}
