package com.netswitch.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.util.TypedValue
import android.view.View

class SimpleUsageBarChartView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var dayUsages: List<DayUsage> = emptyList()
    private val barRect = RectF()

    private fun sp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)
    private fun dp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics)

    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#B08A3E") }
    private val activeBarPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#14463A") }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E8DCBF"); strokeWidth = dp(1f)
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#6F6252"); textSize = sp(10f)
        textAlign = Paint.Align.CENTER; typeface = Typeface.SERIF
    }
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#2B2118"); textSize = sp(9f)
        textAlign = Paint.Align.CENTER; typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
    }

    fun setData(data: List<DayUsage>) {
        dayUsages = data
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (dayUsages.isEmpty()) return
        val left = paddingLeft.toFloat()
        val right = (width - paddingRight).toFloat()
        val top = paddingTop + dp(18f)
        val bottom = (height - paddingBottom) - dp(22f)
        val chartH = bottom - top
        if (chartH <= 0f) return

        for (i in 0..3) {
            val y = bottom - chartH * i / 3f
            canvas.drawLine(left, y, right, y, gridPaint)
        }

        val maxBytes = dayUsages.maxOf { it.totalBytes }.coerceAtLeast(1L)
        val slot = (right - left) / dayUsages.size
        val barW = slot * 0.5f
        dayUsages.forEachIndexed { i, d ->
            val cx = left + slot * i + slot / 2f
            val h = chartH * d.totalBytes / maxBytes
            barRect.set(cx - barW / 2f, bottom - h, cx + barW / 2f, bottom)
            val paint = if (i == dayUsages.lastIndex) activeBarPaint else barPaint
            canvas.drawRoundRect(barRect, dp(4f), dp(4f), paint)
            canvas.drawText(
                android.text.format.Formatter.formatShortFileSize(context, d.totalBytes),
                cx, bottom - h - dp(4f), valuePaint
            )
            canvas.drawText(d.dayLabel, cx, height - paddingBottom - dp(6f), textPaint)
        }
    }
}
