package com.netswitch.app

import android.content.Context
import android.text.format.Formatter
import java.util.Locale

object DataFormatter {
    fun formatBytes(context: Context, bytes: Long): String =
        Formatter.formatFileSize(context, bytes)

    fun formatPercentage(percent: Float): String =
        String.format(Locale.US, "%.1f%%", percent)
}
