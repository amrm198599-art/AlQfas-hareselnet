package com.netswitch.app

import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.netswitch.app.databinding.ItemAppBinding

class AppAdapter(
    private val packageManager: PackageManager,
    private val onToggleBlock: (String, Boolean) -> Unit
) : RecyclerView.Adapter<AppAdapter.AppViewHolder>() {

    private var masterApps: MutableList<AppItem> = mutableListOf()
    private var filteredApps: List<AppItem> = emptyList()
    private var currentFilterQuery: String = ""
    private var showSystem: Boolean = false
    private val iconCache = HashMap<String, Drawable?>()

    inner class AppViewHolder(val binding: ItemAppBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder =
        AppViewHolder(ItemAppBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount(): Int = filteredApps.size

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        val item = filteredApps[position]
        val b = holder.binding
        b.tvAppName.text = item.name
        b.tvPackageName.text = item.packageName
        b.ivAppIcon.setImageDrawable(iconFor(item.packageName))
        b.switchBlock.setOnCheckedChangeListener(null)
        b.switchBlock.isChecked = item.isBlocked
        b.switchBlock.setOnCheckedChangeListener { _, checked ->
            item.isBlocked = checked
            onToggleBlock(item.packageName, checked)
        }
    }

    private fun iconFor(pkg: String): Drawable? = iconCache.getOrPut(pkg) {
        try {
            packageManager.getApplicationIcon(pkg)
        } catch (e: Exception) {
            packageManager.defaultActivityIcon
        }
    }

    fun updateData(apps: List<AppItem>) {
        masterApps = apps.toMutableList()
        applyFilterAndSort()
    }

    fun setShowSystem(value: Boolean) {
        showSystem = value
        applyFilterAndSort()
    }

    fun filter(query: String) {
        currentFilterQuery = query.trim().lowercase()
        applyFilterAndSort()
    }

    fun getAllApps(): List<AppItem> = masterApps

    fun selectAll() = setAllFiltered(true)
    fun deselectAll() = setAllFiltered(false)

    private fun setAllFiltered(value: Boolean) {
        filteredApps.forEach { it.isBlocked = value }
        notifyDataSetChanged()
    }

    private fun applyFilterAndSort() {
        val q = currentFilterQuery
        filteredApps = masterApps
            .filter { it.isSystem == showSystem }
            .filter { q.isEmpty() || it.name.lowercase().contains(q) || it.packageName.lowercase().contains(q) }
            .sortedWith(compareByDescending<AppItem> { it.isBlocked }.thenBy { it.name.lowercase() })
        notifyDataSetChanged()
    }
}
