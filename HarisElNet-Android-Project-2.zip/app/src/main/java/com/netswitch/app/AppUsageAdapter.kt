package com.netswitch.app

import android.content.pm.PackageManager
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.netswitch.app.databinding.ItemAppUsageBinding

class AppUsageAdapter(private val packageManager: PackageManager) :
    RecyclerView.Adapter<AppUsageAdapter.UsageViewHolder>() {

    private var items: List<AppUsageItem> = emptyList()
    private val defaultIcon = packageManager.defaultActivityIcon

    inner class UsageViewHolder(val binding: ItemAppUsageBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: AppUsageItem) {
            val ctx = binding.root.context
            binding.tvAppName.text = item.appName
            binding.tvTotalUsage.text = DataFormatter.formatBytes(ctx, item.totalBytes)
            binding.pbUsage.progress = (item.percentageOfTotal * 10).toInt().coerceIn(0, 1000)
            binding.tvPercentage.text = DataFormatter.formatPercentage(item.percentageOfTotal)
            binding.tvUsageBreakdown.text =
                "تحميل: " + DataFormatter.formatBytes(ctx, item.rxBytes) +
                    " | رفع: " + DataFormatter.formatBytes(ctx, item.txBytes)
            val icon = try {
                packageManager.getApplicationIcon(item.packageName)
            } catch (e: Exception) {
                defaultIcon
            }
            binding.ivAppIcon.setImageDrawable(icon)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        UsageViewHolder(ItemAppUsageBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: UsageViewHolder, position: Int) = holder.bind(items[position])

    fun submitList(list: List<AppUsageItem>) {
        items = list
        notifyDataSetChanged()
    }
}
