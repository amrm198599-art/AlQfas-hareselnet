package com.netswitch.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.net.Uri
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import androidx.recyclerview.widget.LinearLayoutManager
import com.netswitch.app.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: Prefs
    private lateinit var appAdapter: AppAdapter
    private var showSystem = false

    private val vpnPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                BlockerVpnService.startService(this)
            } else {
                Toast.makeText(this, R.string.vpn_permission_denied, Toast.LENGTH_LONG).show()
            }
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* optional */ }

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        runOnUiThread {
            try { updateUiState() } catch (e: Exception) { Log.e(TAG, "Error in prefsListener updateUiState", e) }
        }
    }

    private val vpnStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            try { updateUiState() } catch (e: Exception) { Log.e(TAG, "Error in vpnStateReceiver updateUiState", e) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            binding = ActivityMainBinding.inflate(layoutInflater)
            setContentView(binding.root)
            prefs = Prefs.getInstance(this)
            setupCrashBanner()
            setupRecyclerView()
            setupListeners()
            requestNotificationPermissionIfNeeded()
            updateUiState()
            loadInstalledUserApps()
            maybeShowRatingPrompt()
        } catch (t: Throwable) {
            Log.e(TAG, "Fatal error inside onCreate", t)
            NetSwitchApplication.saveCrash(this, t)
            showFallbackView(t)
        }
    }

    override fun onStart() {
        super.onStart()
        try {
            ContextCompat.registerReceiver(
                this, vpnStateReceiver,
                IntentFilter(BlockerVpnService.ACTION_VPN_STATE_CHANGED),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            prefs.registerListener(prefsListener)
        } catch (e: Exception) {
            Log.e(TAG, "Error in onStart", e)
        }
    }

    override fun onResume() {
        super.onResume()
        try { updateUiState() } catch (e: Exception) { Log.e(TAG, "Error in onResume", e) }
    }

    override fun onStop() {
        try {
            unregisterReceiver(vpnStateReceiver)
            prefs.unregisterListener(prefsListener)
        } catch (_: Exception) {
        }
        super.onStop()
    }

    // ---------------------------------------------------------------- setup

    private fun setupCrashBanner() {
        val crash = NetSwitchApplication.getLastCrash(this)
        if (crash.isNullOrBlank()) return
        binding.cardCrashBanner.visibility = View.VISIBLE
        binding.tvCrashLog.text = crash
        binding.btnCopyCrash.setOnClickListener { copyToClipboard("NetSwitch Crash Log", crash) }
        binding.btnDismissCrash.setOnClickListener {
            NetSwitchApplication.clearLastCrash(this)
            binding.cardCrashBanner.visibility = View.GONE
        }
    }

    private fun copyToClipboard(label: String, text: String) {
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText(label, text))
            Toast.makeText(this, R.string.crash_copied_toast, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to copy: " + e.message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupRecyclerView() {
        appAdapter = AppAdapter(packageManager) { pkg, checked ->
            prefs.setAppBlocked(pkg, checked)
            restartVpnIfActive()
            updateUiState()
        }
        binding.rvApps.layoutManager = LinearLayoutManager(this)
        binding.rvApps.adapter = appAdapter
        binding.rvApps.itemAnimator = null
    }

    private fun setupListeners() {
        binding.btnMainPower.setOnClickListener { toggleProtection() }

        binding.btnModeSelective.setOnClickListener { setMode(blockAll = false) }
        binding.btnModeBlockAll.setOnClickListener { setMode(blockAll = true) }

        binding.searchApps.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                appAdapter.filter(query.orEmpty()); return true
            }
            override fun onQueryTextChange(newText: String?): Boolean {
                appAdapter.filter(newText.orEmpty()); return true
            }
        })

        binding.btnSelectAll.setOnClickListener { appAdapter.selectAll(); persistSelection() }
        binding.btnDeselectAll.setOnClickListener { appAdapter.deselectAll(); persistSelection() }
        binding.btnRetryLoadApps.setOnClickListener { loadInstalledUserApps() }

        binding.navItemUsage.setOnClickListener {
            startActivity(Intent(this, DataUsageActivity::class.java))
        }
        binding.btnTabUserApps.setOnClickListener { setAppsTab(system = false) }
        binding.btnTabSystemApps.setOnClickListener { setAppsTab(system = true) }
    }

    private fun persistSelection() {
        val selected = appAdapter.getAllApps().filter { it.isBlocked }.map { it.packageName }.toSet()
        prefs.setBlockedApps(selected)
        restartVpnIfActive()
        updateUiState()
    }

    private fun setMode(blockAll: Boolean) {
        if (prefs.isBlockAllExceptSelected() == blockAll) return
        prefs.setBlockAllExceptSelected(blockAll)
        restartVpnIfActive()
        updateUiState()
    }

    private fun restartVpnIfActive() {
        if (prefs.isVpnActive()) BlockerVpnService.startService(this)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun toggleProtection() {
        if (prefs.isVpnActive()) {
            BlockerVpnService.stopService(this)
            return
        }
        val intent = VpnService.prepare(this)
        if (intent != null) vpnPermissionLauncher.launch(intent) else BlockerVpnService.startService(this)
    }

    private fun setAppsTab(system: Boolean) {
        if (showSystem == system) return
        showSystem = system
        appAdapter.setShowSystem(system)
        binding.rvApps.scrollToPosition(0)
        updateUiState()
    }

    // ---------------------------------------------------------------- UI state

    private fun updateUiState() {
        val active = prefs.isVpnActive()
        val blockAll = prefs.isBlockAllExceptSelected()
        val selectedCount = prefs.getBlockedApps().size

        binding.btnMainPower.setBackgroundResource(
            if (active) R.drawable.bg_main_button_active else R.drawable.bg_main_button_inactive
        )

        if (active) {
            binding.tvStatus.setText(if (blockAll) R.string.status_all_blocked else R.string.status_blocking_active)
            binding.tvStatusSubtitle.text = if (blockAll) {
                getString(R.string.status_blocking_active_subtitle)
            } else {
                getString(R.string.status_selective_blocked, selectedCount)
            }
        } else {
            binding.tvStatus.setText(R.string.status_net_normal)
            binding.tvStatusSubtitle.setText(R.string.status_net_normal_subtitle)
        }

        binding.switchMainVpn.isChecked = active
        binding.switchBlockAll.isChecked = blockAll
        styleSegment(binding.btnModeSelective, !blockAll)
        styleSegment(binding.btnModeBlockAll, blockAll)
        styleSegment(binding.btnTabUserApps, !showSystem)
        styleSegment(binding.btnTabSystemApps, showSystem)
        binding.tvAppsSectionTitle.setText(
            when {
                showSystem && blockAll -> R.string.apps_section_system_allowed
                showSystem -> R.string.apps_section_system_blocked
                blockAll -> R.string.apps_section_title_allowed
                else -> R.string.apps_section_title_blocked
            }
        )
    }

    private fun styleSegment(tv: TextView, selected: Boolean) {
        tv.setBackgroundResource(if (selected) R.drawable.bg_segmented_active else R.drawable.bg_segmented_inactive)
        tv.setTextColor(ContextCompat.getColor(this, if (selected) R.color.surface_card else R.color.text_secondary))
        tv.setTypeface(Typeface.SERIF, if (selected) Typeface.BOLD else Typeface.NORMAL)
    }

    // ---------------------------------------------------------------- apps list

    private fun isUserApp(ai: ApplicationInfo): Boolean =
        (ai.flags and ApplicationInfo.FLAG_SYSTEM) == 0 ||
            (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0

    private fun loadInstalledUserApps() {
        binding.progressBar.visibility = View.VISIBLE
        binding.layoutAppsError.visibility = View.GONE
        binding.tvAppsEmpty.visibility = View.GONE
        lifecycleScope.launch {
            try {
                val selected = prefs.getBlockedApps()
                val apps = withContext(Dispatchers.IO) {
                    val pm = packageManager
                    pm.getInstalledApplications(0)
                        .filter { it.packageName != packageName }
                        .map {
                            AppItem(
                                pm.getApplicationLabel(it).toString(),
                                it.packageName,
                                it.packageName in selected,
                                !isUserApp(it)
                            )
                        }
                }
                appAdapter.updateData(apps)
                binding.tvAppsEmpty.visibility = if (apps.isEmpty()) View.VISIBLE else View.GONE
            } catch (t: Throwable) {
                Log.e(TAG, "Error loading installed apps", t)
                binding.tvAppsErrorMessage.text = t.localizedMessage ?: t.toString()
                binding.layoutAppsError.visibility = View.VISIBLE
            } finally {
                binding.progressBar.visibility = View.GONE
            }
        }
    }

    // ---------------------------------------------------------------- rating prompt

    /** Polite, skippable request: after 5 launches, then at most once every 30 days. Never blocks the app. */
    private fun maybeShowRatingPrompt() {
        val launches = prefs.incrementLaunchCount()
        if (prefs.isRatingPromptDone() || launches < 5) return
        val now = System.currentTimeMillis()
        if (now - prefs.getLastRatingPrompt() < 30L * 24 * 60 * 60 * 1000) return
        prefs.setLastRatingPrompt(now)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.rating_title)
            .setMessage(R.string.rating_message)
            .setPositiveButton(R.string.rating_now) { _, _ ->
                prefs.setRatingPromptDone()
                openPlayStorePage()
            }
            .setNegativeButton(R.string.rating_later, null)
            .setNeutralButton(R.string.rating_never) { _, _ -> prefs.setRatingPromptDone() }
            .show()
    }

    private fun openPlayStorePage() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
        } catch (e: Exception) {
            startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName"))
            )
        }
    }

    // ---------------------------------------------------------------- fallback

    private fun showFallbackView(t: Throwable) {
        try {
            val trace = Log.getStackTraceString(t)
            val pad = (16 * resources.displayMetrics.density).toInt()
            val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
            root.addView(TextView(this).apply { text = "حارس النت - خطأ في تهيئة الواجهة"; textSize = 18f })
            root.addView(TextView(this).apply { text = "حدث خطأ غير متوقع أثناء فتح الشاشة. تفاصيل الخطأ أدناه قابلة للنسخ:" })
            root.addView(TextView(this).apply { text = trace; textSize = 11f; setTextIsSelectable(true) })
            root.addView(Button(this).apply {
                text = "نسخ تفاصيل الخطأ"
                setOnClickListener { copyToClipboard("Crash Log", trace) }
            })
            setContentView(ScrollView(this).apply { addView(root) })
        } catch (e: Throwable) {
            Log.e(TAG, "Failed even fallback view", e)
        }
    }

    companion object {
        private const val TAG = "MainActivity"
    }
}
