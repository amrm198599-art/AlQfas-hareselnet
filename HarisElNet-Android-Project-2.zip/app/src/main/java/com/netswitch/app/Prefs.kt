package com.netswitch.app

import android.content.Context
import android.content.SharedPreferences

class Prefs private constructor(context: Context) {

    private val sharedPreferences: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun isVpnActive(): Boolean = sharedPreferences.getBoolean(KEY_VPN_ACTIVE, false)
    fun setVpnActive(value: Boolean) = sharedPreferences.edit().putBoolean(KEY_VPN_ACTIVE, value).apply()

    /** false = "حظر المحدد فقط", true = "قطع الكل ما عدا المحدد". */
    fun isBlockAllEnabled(): Boolean = sharedPreferences.getBoolean(KEY_BLOCK_ALL, false)
    fun setBlockAllEnabled(value: Boolean) = sharedPreferences.edit().putBoolean(KEY_BLOCK_ALL, value).apply()
    fun isBlockAllExceptSelected(): Boolean = isBlockAllEnabled()
    fun setBlockAllExceptSelected(value: Boolean) = setBlockAllEnabled(value)

    fun getBlockedApps(): Set<String> =
        HashSet(sharedPreferences.getStringSet(KEY_BLOCKED_APPS, emptySet()) ?: emptySet())

    fun setBlockedApps(apps: Set<String>) =
        sharedPreferences.edit().putStringSet(KEY_BLOCKED_APPS, HashSet(apps)).apply()

    fun getBlockedPackages(): Set<String> = getBlockedApps()
    fun setBlockedPackages(apps: Set<String>) = setBlockedApps(apps)

    fun isAppBlocked(packageName: String): Boolean = getBlockedApps().contains(packageName)

    fun setAppBlocked(packageName: String, blocked: Boolean) {
        val set = getBlockedApps().toMutableSet()
        if (blocked) set.add(packageName) else set.remove(packageName)
        setBlockedApps(set)
    }

    fun setAllAppsBlocked(packages: Collection<String>, blocked: Boolean) {
        val set = getBlockedApps().toMutableSet()
        if (blocked) set.addAll(packages) else set.removeAll(packages.toSet())
        setBlockedApps(set)
    }

    fun clearAllBlockedApps() = setBlockedApps(emptySet())

    fun getDailyMobileLimitMb(): Int = sharedPreferences.getInt(KEY_DAILY_MOBILE_LIMIT_MB, 0)
    fun setDailyMobileLimitMb(value: Int) =
        sharedPreferences.edit().putInt(KEY_DAILY_MOBILE_LIMIT_MB, value).apply()

    fun getLastAlert80Day(): Long = sharedPreferences.getLong(KEY_LAST_ALERT_80_DAY, 0L)
    fun setLastAlert80Day(value: Long) = sharedPreferences.edit().putLong(KEY_LAST_ALERT_80_DAY, value).apply()
    fun getLastAlert100Day(): Long = sharedPreferences.getLong(KEY_LAST_ALERT_100_DAY, 0L)
    fun setLastAlert100Day(value: Long) = sharedPreferences.edit().putLong(KEY_LAST_ALERT_100_DAY, value).apply()

    fun incrementLaunchCount(): Int {
        val n = sharedPreferences.getInt(KEY_LAUNCH_COUNT, 0) + 1
        sharedPreferences.edit().putInt(KEY_LAUNCH_COUNT, n).apply()
        return n
    }

    fun isRatingPromptDone(): Boolean = sharedPreferences.getBoolean(KEY_RATING_DONE, false)
    fun setRatingPromptDone() = sharedPreferences.edit().putBoolean(KEY_RATING_DONE, true).apply()
    fun getLastRatingPrompt(): Long = sharedPreferences.getLong(KEY_LAST_RATING_PROMPT, 0L)
    fun setLastRatingPrompt(value: Long) =
        sharedPreferences.edit().putLong(KEY_LAST_RATING_PROMPT, value).apply()

    fun registerListener(l: SharedPreferences.OnSharedPreferenceChangeListener) =
        sharedPreferences.registerOnSharedPreferenceChangeListener(l)

    fun unregisterListener(l: SharedPreferences.OnSharedPreferenceChangeListener) =
        sharedPreferences.unregisterOnSharedPreferenceChangeListener(l)

    companion object {
        private const val PREFS_NAME = "haris_el_net_prefs"
        private const val KEY_VPN_ACTIVE = "key_vpn_active"
        private const val KEY_BLOCK_ALL = "key_block_all"
        private const val KEY_BLOCKED_APPS = "key_blocked_apps"
        private const val KEY_DAILY_MOBILE_LIMIT_MB = "key_daily_mobile_limit_mb"
        private const val KEY_LAST_ALERT_80_DAY = "key_last_alert_80_day"
        private const val KEY_LAST_ALERT_100_DAY = "key_last_alert_100_day"
        private const val KEY_LAUNCH_COUNT = "key_launch_count"
        private const val KEY_RATING_DONE = "key_rating_done"
        private const val KEY_LAST_RATING_PROMPT = "key_last_rating_prompt"

        @Volatile
        private var instance: Prefs? = null

        fun getInstance(context: Context): Prefs =
            instance ?: synchronized(this) {
                instance ?: Prefs(context).also { instance = it }
            }
    }
}
