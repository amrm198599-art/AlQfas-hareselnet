package com.netswitch.app

import android.app.Application
import android.content.Context
import android.util.Log
import java.io.PrintWriter
import java.io.StringWriter

class NetSwitchApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                Log.e(TAG, "Uncaught exception caught in global crash handler", throwable)
                saveCrash(applicationContext, throwable)
            } catch (t: Throwable) {
                Log.e(TAG, "Error handling uncaught exception", t)
            }
            previous?.uncaughtException(thread, throwable)
        }
    }

    companion object {
        private const val TAG = "NetSwitchApplication"
        private const val PREFS_CRASH = "netswitch_crashes"
        private const val KEY_LAST_CRASH = "key_last_crash_trace"
        private const val KEY_LAST_CRASH_TIMESTAMP = "key_last_crash_timestamp"

        fun saveCrash(context: Context, throwable: Throwable) {
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                context.getSharedPreferences(PREFS_CRASH, Context.MODE_PRIVATE).edit()
                    .putString(KEY_LAST_CRASH, sw.toString())
                    .putLong(KEY_LAST_CRASH_TIMESTAMP, System.currentTimeMillis())
                    .commit()
            } catch (t: Throwable) {
                Log.e(TAG, "Failed to save crash report", t)
            }
        }

        fun getLastCrash(context: Context): String? = try {
            context.getSharedPreferences(PREFS_CRASH, Context.MODE_PRIVATE).getString(KEY_LAST_CRASH, null)
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to check previous crash", t)
            null
        }

        fun clearLastCrash(context: Context) {
            context.getSharedPreferences(PREFS_CRASH, Context.MODE_PRIVATE).edit()
                .remove(KEY_LAST_CRASH).remove(KEY_LAST_CRASH_TIMESTAMP).apply()
        }
    }
}
