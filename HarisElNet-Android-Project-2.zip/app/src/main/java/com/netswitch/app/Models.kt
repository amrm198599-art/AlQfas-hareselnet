package com.netswitch.app

data class AppItem(
    val name: String,
    val packageName: String,
    var isBlocked: Boolean,
    val isSystem: Boolean = false
)

data class AppUsageItem(
    val uid: Int,
    val appName: String,
    val packageName: String,
    val rxBytes: Long,
    val txBytes: Long,
    val totalBytes: Long,
    val percentageOfTotal: Float
)

data class DayUsage(val dateEpochMs: Long, val dayLabel: String, val totalBytes: Long)

data class NetworkUsageSummary(val rxBytes: Long, val txBytes: Long) {
    val totalBytes: Long get() = rxBytes + txBytes
}
