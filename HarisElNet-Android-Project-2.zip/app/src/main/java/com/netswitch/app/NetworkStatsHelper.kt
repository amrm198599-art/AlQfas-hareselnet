package com.netswitch.app

import android.annotation.SuppressLint
import android.app.AppOpsManager
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.net.ConnectivityManager
import android.os.Build
import android.os.Process
import android.telephony.TelephonyManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar

class NetworkStatsHelper(private val context: Context) {

    private val networkStatsManager =
        context.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager

    fun hasUsageStatsPermission(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow("android:get_usage_stats", Process.myUid(), context.packageName)
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow("android:get_usage_stats", Process.myUid(), context.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    @SuppressLint("HardwareIds", "MissingPermission")
    private fun getSubscriberId(networkType: Int): String? {
        if (networkType != ConnectivityManager.TYPE_MOBILE) return null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) return null
        return try {
            val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            tm.subscriberId
        } catch (e: Exception) {
            null
        }
    }

    suspend fun querySummaryForNetwork(networkType: Int, startTime: Long, endTime: Long): NetworkUsageSummary =
        withContext(Dispatchers.IO) {
            try {
                val bucket = networkStatsManager.querySummaryForDevice(
                    networkType, getSubscriberId(networkType), startTime, endTime
                )
                NetworkUsageSummary(bucket.rxBytes, bucket.txBytes)
            } catch (e: Exception) {
                NetworkUsageSummary(0L, 0L)
            }
        }

    suspend fun queryAppsUsage(startTime: Long, endTime: Long): List<AppUsageItem> =
        withContext(Dispatchers.IO) {
            val perUid = HashMap<Int, LongArray>()
            for (type in intArrayOf(ConnectivityManager.TYPE_MOBILE, ConnectivityManager.TYPE_WIFI)) {
                try {
                    val stats = networkStatsManager.querySummary(type, getSubscriberId(type), startTime, endTime)
                    aggregateBuckets(stats, perUid)
                } catch (e: Exception) {
                    // ignore this network type
                }
            }
            val grand = perUid.values.sumOf { it[0] + it[1] }.coerceAtLeast(1L)
            val pm = context.packageManager
            perUid.entries
                .filter { it.value[0] + it.value[1] > 0 }
                .map { (uid, v) ->
                    val pkg = pm.getPackagesForUid(uid)?.firstOrNull() ?: "uid_$uid"
                    val name = when {
                        uid == 1000 -> "نظام أندرويد (OS)"
                        pkg.startsWith("uid_") -> "تطبيق ($uid)"
                        else -> try {
                            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                        } catch (e: Exception) {
                            pkg
                        }
                    }
                    val total = v[0] + v[1]
                    AppUsageItem(uid, name, pkg, v[0], v[1], total, total * 100f / grand)
                }
                .sortedByDescending { it.totalBytes }
        }

    suspend fun queryLast7DaysUsage(): List<DayUsage> = withContext(Dispatchers.IO) {
        val names = arrayOf("الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")
        val result = ArrayList<DayUsage>()
        for (i in 6 downTo 0) {
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
            cal.add(Calendar.DAY_OF_YEAR, -i)
            val start = cal.timeInMillis
            val label = names[cal.get(Calendar.DAY_OF_WEEK) - 1]
            cal.add(Calendar.DAY_OF_YEAR, 1)
            val end = if (i == 0) System.currentTimeMillis() else cal.timeInMillis
            val mobile = querySummaryForNetwork(ConnectivityManager.TYPE_MOBILE, start, end)
            val wifi = querySummaryForNetwork(ConnectivityManager.TYPE_WIFI, start, end)
            result.add(DayUsage(start, label, mobile.totalBytes + wifi.totalBytes))
        }
        result
    }

    private fun aggregateBuckets(stats: NetworkStats?, into: MutableMap<Int, LongArray>) {
        if (stats == null) return
        val bucket = NetworkStats.Bucket()
        while (stats.hasNextBucket()) {
            stats.getNextBucket(bucket)
            val arr = into.getOrPut(bucket.uid) { LongArray(2) }
            arr[0] += bucket.rxBytes
            arr[1] += bucket.txBytes
        }
        stats.close()
    }
}
