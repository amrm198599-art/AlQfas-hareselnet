package com.netswitch.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import java.util.Calendar

class DailyLimitWorker(private val context: Context, params: WorkerParameters) :
    CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val prefs = Prefs.getInstance(context)
        val limitMb = prefs.getDailyMobileLimitMb()
        if (limitMb <= 0) return Result.success()

        val helper = NetworkStatsHelper(context)
        if (!helper.hasUsageStatsPermission()) return Result.success()

        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        val dayStart = cal.timeInMillis

        val usage = helper.querySummaryForNetwork(ConnectivityManager.TYPE_MOBILE, dayStart, System.currentTimeMillis())
        val used = usage.totalBytes
        val limitBytes = limitMb.toLong() * 1024L * 1024L
        val percent = if (limitBytes > 0) (used * 100L / limitBytes).toInt() else 0

        if (used >= limitBytes) {
            if (prefs.getLastAlert100Day() != dayStart) {
                showLimitNotification(
                    context.getString(R.string.usage_limit_alert_100_title),
                    context.getString(R.string.usage_limit_alert_100_desc, limitMb),
                    2002
                )
                prefs.setLastAlert100Day(dayStart)
                prefs.setLastAlert80Day(dayStart)
            }
        } else if (used * 100L >= limitBytes * 80L && prefs.getLastAlert80Day() != dayStart) {
            showLimitNotification(
                context.getString(R.string.usage_limit_alert_80_title),
                context.getString(
                    R.string.usage_limit_alert_80_desc,
                    DataFormatter.formatBytes(context, used), limitMb, percent
                ),
                2001
            )
            prefs.setLastAlert80Day(dayStart)
        }
        return Result.success()
    }

    private fun showLimitNotification(title: String, text: String, id: Int) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    context.getString(R.string.usage_alert_channel_name),
                    NotificationManager.IMPORTANCE_HIGH
                ).apply { description = context.getString(R.string.usage_alert_channel_desc) }
            )
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return
        val n = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_lock)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(id, n)
        } catch (_: SecurityException) {
        }
    }

    companion object {
        const val CHANNEL_ID = "channel_usage_alerts"
        const val UNIQUE_WORK_NAME = "haris_daily_limit_work"
    }
}
