package com.netswitch.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/**
 * Local "sinkhole" VPN: routes the chosen apps' traffic into a TUN interface that nobody reads,
 * which effectively cuts their internet access.
 */
class BlockerVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private lateinit var prefs: Prefs
    private var stopping = false

    private val criticalSystemPackages = setOf(
        "com.google.android.gms",
        "com.android.vending",
        "com.google.android.gsf"
    )

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs.getInstance(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopVpn()
            return START_NOT_STICKY
        }
        stopping = false
        startForegroundServiceWithNotification()
        startVpn()
        return START_STICKY
    }

    private fun startVpn() {
        closeInterface()
        val pm = packageManager
        val builder = Builder()
            .setSession(getString(R.string.vpn_session_name))
            .addAddress("10.111.222.1", 32)
            .addRoute("0.0.0.0", 0)
            .setMtu(1500)

        try {
            builder.addAddress("fd00:111:222::1", 128)
            builder.addRoute("::", 0)
        } catch (e: Exception) {
            Log.w(TAG, "IPv6 route not supported", e)
        }

        val selected = prefs.getBlockedApps()

        if (prefs.isBlockAllExceptSelected()) {
            // Everything goes into the sinkhole EXCEPT: this app, selected apps, system apps.
            try {
                builder.addDisallowedApplication(packageName)
            } catch (e: PackageManager.NameNotFoundException) {
                Log.w(TAG, "Own package not found", e)
            }
            for (pkg in selected) {
                try {
                    builder.addDisallowedApplication(pkg)
                } catch (e: PackageManager.NameNotFoundException) {
                    Log.w(TAG, "NameNotFoundException bypassing: $pkg")
                }
            }
        } else {
            var count = 0
            for (pkg in selected) {
                if (pkg == packageName) continue
                try {
                    builder.addAllowedApplication(pkg)
                    count++
                } catch (e: PackageManager.NameNotFoundException) {
                    Log.w(TAG, "NameNotFoundException targeting: $pkg")
                }
            }
            if (count == 0) {
                Log.w(TAG, "No valid apps selected; not starting VPN")
                stopVpn()
                return
            }
        }

        try {
            vpnInterface = builder.establish()
        } catch (e: Exception) {
            Log.e(TAG, "VPN Start failed", e)
            vpnInterface = null
        }

        if (vpnInterface == null) {
            stopVpn()
            return
        }
        prefs.setVpnActive(true)
        broadcastState(true)
    }

    private fun isUserApp(ai: ApplicationInfo): Boolean =
        (ai.flags and ApplicationInfo.FLAG_SYSTEM) == 0 ||
            (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0

    private fun closeInterface() {
        try {
            vpnInterface?.close()
        } catch (e: Exception) {
            Log.e(TAG, "Error closing descriptor", e)
        }
        vpnInterface = null
    }

    private fun stopVpn() {
        if (stopping) return
        stopping = true
        closeInterface()
        prefs.setVpnActive(false)
        broadcastState(false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun broadcastState(running: Boolean) {
        sendBroadcast(
            Intent(ACTION_VPN_STATE_CHANGED)
                .setPackage(packageName)
                .putExtra(EXTRA_IS_RUNNING, running)
        )
    }

    private fun startForegroundServiceWithNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notification_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply { description = getString(R.string.notification_channel_desc) }
        nm.createNotificationChannel(channel)

        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 1, Intent(this, BlockerVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_lock)
            .setContentTitle(getString(R.string.notification_title_blocked))
            .setContentText(getString(R.string.vpn_status_active))
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(0, getString(R.string.notification_action_restore_net), stopIntent)
            .build()
        startForeground(NOTIFICATION_ID, notification)
    }

    override fun onRevoke() {
        stopVpn()
        super.onRevoke()
    }

    override fun onDestroy() {
        if (!stopping) {
            stopping = true
            closeInterface()
            prefs.setVpnActive(false)
            broadcastState(false)
        }
        super.onDestroy()
    }

    companion object {
        private const val TAG = "BlockerVpnService"
        const val ACTION_START = "com.netswitch.app.ACTION_START"
        const val ACTION_STOP = "com.netswitch.app.ACTION_STOP"
        const val ACTION_VPN_STATE_CHANGED = "com.netswitch.app.ACTION_VPN_STATE_CHANGED"
        const val EXTRA_IS_RUNNING = "extra_is_running"
        private const val CHANNEL_ID = "haris_el_net_channel"
        private const val NOTIFICATION_ID = 1001

        fun startService(context: Context) {
            val intent = Intent(context, BlockerVpnService::class.java).setAction(ACTION_START)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stopService(context: Context) {
            val intent = Intent(context, BlockerVpnService::class.java).setAction(ACTION_STOP)
            try {
                context.startService(intent)
            } catch (e: Exception) {
                context.stopService(Intent(context, BlockerVpnService::class.java))
                Prefs.getInstance(context).setVpnActive(false)
            }
        }
    }
}
