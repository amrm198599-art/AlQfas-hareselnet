package com.netswitch.app

import android.app.PendingIntent
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.drawable.Icon
import android.net.VpnService
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class NetSwitchTile : TileService() {

    private lateinit var prefs: Prefs
    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> updateTileState() }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs.getInstance(this)
    }

    override fun onStartListening() {
        super.onStartListening()
        prefs.registerListener(prefsListener)
        updateTileState()
    }

    override fun onStopListening() {
        prefs.unregisterListener(prefsListener)
        super.onStopListening()
    }

    @Suppress("DEPRECATION")
    override fun onClick() {
        super.onClick()
        if (prefs.isVpnActive()) {
            BlockerVpnService.stopService(this)
            return
        }
        if (VpnService.prepare(this) != null) {
            val intent = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (Build.VERSION.SDK_INT >= 34) {
                startActivityAndCollapse(
                    PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
                )
            } else {
                startActivityAndCollapse(intent)
            }
        } else {
            BlockerVpnService.startService(this)
        }
    }

    private fun updateTileState() {
        val tile = qsTile ?: return
        val active = prefs.isVpnActive()
        tile.state = if (active) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = getString(R.string.tile_label)
        if (Build.VERSION.SDK_INT >= 29) {
            tile.subtitle = getString(if (active) R.string.tile_status_active else R.string.tile_status_inactive)
        }
        tile.icon = Icon.createWithResource(this, R.drawable.ic_stat_lock)
        tile.updateTile()
    }
}
