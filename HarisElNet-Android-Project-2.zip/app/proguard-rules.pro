# R8/ProGuard is disabled for release builds (isMinifyEnabled = false).
